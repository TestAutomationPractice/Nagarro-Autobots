import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('http://autothon-nagarro-frontend-x09.azurewebsites.net/')

WebUI.delay(2)

WebUI.click(findTestObject('MovieRentalService/AddMovie/Page_React App/a_Login'))

WebUI.delay(2)

WebUI.setText(findTestObject('MovieRentalService/AddMovie/Page_React App/InputUserName'), 'admin')

WebUI.setText(findTestObject('MovieRentalService/AddMovie/Page_React App/InputPassword'), 'password')

WebUI.click(findTestObject('MovieRentalService/AddMovie/Page_React App/button_Login'))

WebUI.waitForElementVisible(findTestObject('MovieRentalService/AddMovie/Page_React App/a_add movie'), 0)

WebUI.click(findTestObject('MovieRentalService/AddMovie/Page_React App/a_add movie'))

WebUI.setText(findTestObject('MovieRentalService/AddMovie/Page_React App/input_Title_title'), 'Prince of Persia')

WebUI.setText(findTestObject('MovieRentalService/AddMovie/Page_React App/input_Director_director'), 'Mike newell')

WebUI.setText(findTestObject('MovieRentalService/AddMovie/Page_React App/textarea_Description_description'), 'Prince of Persia')

WebUI.selectOptionByValue(findTestObject('MovieRentalService/AddMovie/Page_React App/select_ComedyDramaThriller'), 'Thriller', 
    false)

WebUI.setText(findTestObject('MovieRentalService/AddMovie/Page_React App/input_URL_file'), 'https://www.imdb.com/title/tt0473075/mediaviewer/rm521375488')

WebUI.focus(findTestObject('MovieRentalService/AddMovie/Page_React App/div_Looks good'))

WebUI.mouseOver(findTestObject('MovieRentalService/AddMovie/Page_React App/div_Looks good'))

